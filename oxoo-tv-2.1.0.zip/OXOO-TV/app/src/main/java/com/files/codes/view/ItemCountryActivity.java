package com.files.codes.view;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.files.codes.R;

public class ItemCountryActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_country);
    }
}