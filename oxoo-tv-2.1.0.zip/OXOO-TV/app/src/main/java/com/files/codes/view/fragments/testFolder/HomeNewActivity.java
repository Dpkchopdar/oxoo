package com.files.codes.view.fragments.testFolder;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.files.codes.R;

public class HomeNewActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_new);
    }
}